BLOXYMAN STUDIO
Version 1.0

==============================
HOW TO RUN
==============================

1. Right-click the ZIP file.
2. Select "Extract All".
3. Open the extracted folder.
4. Double-click "bloxyman_studio.exe".

If Windows shows a security warning:
- Click "More Info"
- Click "Run Anyway"

==============================
FEATURES
==============================

- Block placing system (Left Click)
- Block delete system (Right Click)
- Stickman player
- Collision system
- Gravity system
- Start / Stop physics
- Script system
- Save / Open project files

==============================
CONTROLS
==============================

A = Move Left
D = Move Right
SPACE = Jump

Run All = Start gravity
Stop = Reset player position

==============================
IMPORTANT NOTES
==============================

- Make sure you extract the ZIP file before running.
- Do not run the EXE file inside the ZIP.
- If blocked by antivirus, allow the file to run.

==============================
Thank you for using Bloxyman Studio!
==============================